import React from "react";
import useYouTube from "./useYouTube";

export default function App() {
  const playerRef = React.useRef();
  const [ready, player] = useYouTube(playerRef.current, "Bey4XXJAqS8");
  const [play, setPlay] = React.useState(false);
  const [playLayout, setPlayLayout] = React.useState(false);
  const [playClick, setPlayClick] = React.useState(false);
  const hasPlayed = play || playLayout || playClick;

  React.useEffect(() => {
    if (play) player.playVideo();
  }, [play, player]);

  React.useLayoutEffect(() => {
    if (playLayout) player.playVideo();
  }, [playLayout, player]);

  return (
    <div>
      <h1>iOS - YouTube iFrame API play via effect / layoutEffect / onClick</h1>
      <p>
        The "play effect" button will not start the video on iOS. use the
        "useLayoutEffect" hook or an event handler
      </p>
      <div ref={playerRef} />
      <div>
        {ready ? (
          hasPlayed ? (
            <button onClick={() => window.location.reload()}>Reset</button>
          ) : (
            <>
              <button onClick={() => setPlay(true)}>play - effect</button>
              <button onClick={() => setPlayLayout(true)}>
                play - layout effect
              </button>
              <button
                onClick={() => {
                  setPlayClick(true);
                  player.playVideo();
                }}
              >
                play - onclick
              </button>
            </>
          )
        ) : null}
      </div>
    </div>
  );
}
